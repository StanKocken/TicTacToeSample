package com.skocken.ui.presentation.provider;


import com.skocken.ui.presentation.Base;

import java.lang.ref.WeakReference;

public abstract class BaseDataProvider<P extends Base.IPresenter> implements Base.IDataProvider {

    private WeakReference<P> mPresenter;

    @Override
    public void setPresenter(Base.IPresenter presenter) {
        mPresenter = new WeakReference((P) presenter);
    }

    public P getPresenter() {
        return mPresenter.get();
    }
}
