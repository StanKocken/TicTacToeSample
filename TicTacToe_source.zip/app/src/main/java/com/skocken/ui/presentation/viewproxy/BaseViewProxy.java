package com.skocken.ui.presentation.viewproxy;


import com.skocken.ui.presentation.Base;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.util.SparseArray;
import android.view.View;
import android.widget.TextView;

public abstract class BaseViewProxy implements Base.IView {

    private View mRootView;

    private SparseArray<View> mCachedViewFind = new SparseArray<View>();

    public BaseViewProxy(Activity activity) {
        this(activity.findViewById(android.R.id.content));
    }

    public BaseViewProxy(View rootView) {
        mRootView = rootView;
        onInit();
    }

    protected void onInit() {
    }

    public <T extends View> T getRootView() {
        return (T) mRootView;
    }

    @Override
    public Context getContext() {
        return mRootView.getContext();
    }

    @Override
    public Resources getResources() {
        return mRootView.getResources();
    }

    public <T extends View> T findViewByIdEfficient(int id) {
        View view = mCachedViewFind.get(id);
        if (view == null) {
            view = mRootView.findViewById(id);
            mCachedViewFind.put(id, view);
        }
        return (T) view;
    }

    protected void setTextOnTextView(int tvResId, String text) {
        ((TextView) findViewByIdEfficient(tvResId)).setText(text);
    }
}
