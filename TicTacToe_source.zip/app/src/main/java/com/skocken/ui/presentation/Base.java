package com.skocken.ui.presentation;

import android.content.Context;
import android.content.res.Resources;

public class Base {

    public interface IPresenter {

        Context getContext();

        Resources getResources();
    }

    public interface IDataProvider {

        void setPresenter(IPresenter pvBasePresenter);
    }

    public interface IView {

        Context getContext();

        Resources getResources();
    }
}
