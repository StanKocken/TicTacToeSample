package com.skocken.ui.presentation.presenter;

import com.skocken.ui.presentation.Base;

import android.content.Context;
import android.content.res.Resources;

public abstract class BasePresenter<P extends Base.IDataProvider, V extends Base.IView>
        implements Base.IPresenter {

    private P mProvider;

    private V mView;

    public BasePresenter(P provider, V view) {
        mProvider = provider;
        mView = view;

        if (mProvider != null) {
            mProvider.setPresenter(this);
        }
    }

    protected P getProvider() {
        return mProvider;
    }

    protected V getView() {
        return mView;
    }

    @Override
    public Context getContext() {
        return mView.getContext();
    }

    @Override
    public Resources getResources() {
        return mView.getResources();
    }
}
