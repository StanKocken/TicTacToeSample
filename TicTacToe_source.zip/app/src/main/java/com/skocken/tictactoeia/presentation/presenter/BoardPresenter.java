package com.skocken.tictactoeia.presentation.presenter;


import com.skocken.tictactoeia.GameBoard;
import com.skocken.tictactoeia.presentation.Board;
import com.skocken.ui.presentation.presenter.BasePresenter;

public class BoardPresenter extends BasePresenter<Board.IDataProvider, Board.IView>
        implements Board.IPresenter, Board.IView.BoxClickListener {

    public BoardPresenter(Board.IDataProvider provider, Board.IView view) {
        super(provider, view);
        init();
    }

    private void init() {
        Board.IView view = getView();
        view.setBoxClickListener(this);
        refreshBoard();
    }

    @Override
    public void refreshBoard() {
        Board.IView view = getView();

        GameBoard gameBoard = getProvider().getGameBoard();
        int size = gameBoard.getSize();
        for (int y = 0; y < size; y++) {
            for (int x = 0; x < size; x++) {
                GameBoard.Player player = gameBoard.getPlayer(x, y);

                Board.IView.BoxValue boxValue;
                switch (player) {
                    case EMPTY:
                        boxValue = Board.IView.BoxValue.EMPTY;
                        break;
                    case J1:
                        boxValue = Board.IView.BoxValue.CROSS;
                        break;
                    case J2:
                        boxValue = Board.IView.BoxValue.ROUND;
                        break;
                    default:
                        continue;
                }
                view.setBoxValue(x, y, boxValue);
            }
        }
    }

    @Override
    public void onSelectBox(int x, int y) {
        getProvider().play(x, y);
    }
}
