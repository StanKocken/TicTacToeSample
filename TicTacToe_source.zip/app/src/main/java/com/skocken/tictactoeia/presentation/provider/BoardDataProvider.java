package com.skocken.tictactoeia.presentation.provider;

import com.skocken.tictactoeia.GameBoard;
import com.skocken.tictactoeia.IA;
import com.skocken.tictactoeia.presentation.Board;
import com.skocken.ui.presentation.provider.BaseDataProvider;

public class BoardDataProvider extends BaseDataProvider<Board.IPresenter>
        implements Board.IDataProvider {

    private IA mIA;

    private GameBoard mGameBoard = new GameBoard();

    private GameBoard.Player mCurrentPlayer = GameBoard.Player.J1;

    @Override
    public GameBoard getGameBoard() {
        return mGameBoard;
    }

    @Override
    public void play(int x, int y) {
        mGameBoard.play(mCurrentPlayer, x, y);

        if (mIA == null) {
            GameBoard.Player iaPlayer;
            if (mCurrentPlayer == GameBoard.Player.J1) {
                iaPlayer = GameBoard.Player.J2;
            } else {
                iaPlayer = GameBoard.Player.J1;
            }
            mIA = new IA(mGameBoard, iaPlayer);
        }
        mIA.playNext();
        getPresenter().refreshBoard();
    }
}
