package com.skocken.tictactoeia.presentation;

import com.skocken.tictactoeia.GameBoard;
import com.skocken.ui.presentation.Base;

public class Board {

    public interface IPresenter extends Base.IPresenter {

        void refreshBoard();
    }

    public interface IDataProvider extends Base.IDataProvider {

        GameBoard getGameBoard();

        void play(int x, int y);
    }

    public interface IView extends Base.IView {

        enum BoxValue {
            CROSS, ROUND, EMPTY;
        }

        interface BoxClickListener {

            void onSelectBox(int x, int y);
        }

        void setBoxValue(int x, int y, BoxValue value);

        void setBoxClickListener(BoxClickListener listener);
    }
}
