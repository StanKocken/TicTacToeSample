package com.skocken.tictactoeia;

import com.skocken.tictactoeia.presentation.presenter.BoardPresenter;
import com.skocken.tictactoeia.presentation.provider.BoardDataProvider;
import com.skocken.tictactoeia.presentation.viewproxy.BoardViewProxy;

import android.app.Activity;
import android.os.Bundle;


public class MainActivity extends Activity {

    private BoardPresenter mPresenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mPresenter = new BoardPresenter(new BoardDataProvider(), new BoardViewProxy(this));
    }
}
