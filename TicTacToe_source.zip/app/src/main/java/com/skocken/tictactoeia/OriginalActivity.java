package com.skocken.tictactoeia;

import com.skocken.tictactoeia.presentation.Board;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;

public class OriginalActivity extends Activity implements View.OnClickListener {

    private IA mIA;

    private GameBoard mGameBoard = new GameBoard();

    private GameBoard.Player mCurrentPlayer = GameBoard.Player.J1;

    private ViewGroup mBoxesLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mBoxesLayout = (ViewGroup) findViewById(R.id.boxes_layout);
    }

    private void refreshBoard() {
        int size = mGameBoard.getSize();
        for (int y = 0; y < size; y++) {
            for (int x = 0; x < size; x++) {
                GameBoard.Player player = mGameBoard.getPlayer(x, y);

                Board.IView.BoxValue boxValue;
                switch (player) {
                    case EMPTY:
                        boxValue = Board.IView.BoxValue.EMPTY;
                        break;
                    case J1:
                        boxValue = Board.IView.BoxValue.CROSS;
                        break;
                    case J2:
                        boxValue = Board.IView.BoxValue.ROUND;
                        break;
                    default:
                        continue;
                }
                setBoxValue(x, y, boxValue);
            }
        }
    }

    private void setBoxValue(int x, int y, Board.IView.BoxValue value) {
        ViewGroup rowLayout = (ViewGroup) mBoxesLayout.getChildAt(y);
        View boxView = rowLayout.getChildAt(x);

        int bgColor;
        switch (value) {
            case CROSS:
                bgColor = Color.RED;
                boxView.setOnClickListener(null);
                break;
            case ROUND:
                bgColor = Color.BLUE;
                boxView.setOnClickListener(null);
                break;
            case EMPTY:
                bgColor = Color.GRAY;
                boxView.setOnClickListener(this);
                break;
            default:
                return;
        }
        boxView.setBackgroundColor(bgColor);
        boxView.setTag(R.id.tag_x, x);
        boxView.setTag(R.id.tag_y, y);
    }

    @Override
    public void onClick(View v) {
        Object x = v.getTag(R.id.tag_x);
        Object y = v.getTag(R.id.tag_y);
        if (x instanceof Integer && y instanceof Integer) {
            play((int) x, (int) y);
        }
    }

    private void play(int x, int y) {
        mGameBoard.play(mCurrentPlayer, x, y);

        if (mIA == null) {
            GameBoard.Player iaPlayer;
            if (mCurrentPlayer == GameBoard.Player.J1) {
                iaPlayer = GameBoard.Player.J2;
            } else {
                iaPlayer = GameBoard.Player.J1;
            }
            mIA = new IA(mGameBoard, iaPlayer);
        }
        mIA.playNext();
        refreshBoard();
    }
}
