package com.skocken.tictactoeia.presentation.viewproxy;

import com.skocken.tictactoeia.R;
import com.skocken.tictactoeia.presentation.Board;
import com.skocken.ui.presentation.viewproxy.BaseViewProxy;

import android.app.Activity;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;

public class BoardViewProxy extends BaseViewProxy implements Board.IView, View.OnClickListener {

    private ViewGroup mBoxesLayout;

    private BoxClickListener mBoxClickListener;

    public BoardViewProxy(Activity activity) {
        super(activity);
    }

    @Override
    protected void onInit() {
        super.onInit();
        mBoxesLayout = (ViewGroup) getRootView().findViewById(R.id.boxes_layout);
    }

    @Override
    public void setBoxValue(int x, int y, BoxValue value) {
        ViewGroup rowLayout = (ViewGroup) mBoxesLayout.getChildAt(y);
        View boxView = rowLayout.getChildAt(x);

        int bgColor;
        switch (value) {
            case CROSS:
                bgColor = Color.RED;
                boxView.setOnClickListener(null);
                break;
            case ROUND:
                bgColor = Color.BLUE;
                boxView.setOnClickListener(null);
                break;
            case EMPTY:
                bgColor = Color.GRAY;
                boxView.setOnClickListener(this);
                break;
            default:
                return;
        }
        boxView.setBackgroundColor(bgColor);
        boxView.setTag(R.id.tag_x, x);
        boxView.setTag(R.id.tag_y, y);
    }

    @Override
    public void setBoxClickListener(BoxClickListener listener) {
        mBoxClickListener = listener;
    }

    @Override
    public void onClick(View v) {
        if (mBoxClickListener == null) {
            return;
        }
        Object x = v.getTag(R.id.tag_x);
        Object y = v.getTag(R.id.tag_y);
        if (x instanceof Integer && y instanceof Integer) {
            mBoxClickListener.onSelectBox((int) x, (int) y);
        }
    }
}
