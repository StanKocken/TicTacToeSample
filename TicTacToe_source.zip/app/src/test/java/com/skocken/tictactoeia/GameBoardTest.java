package com.skocken.tictactoeia;

import junit.framework.TestCase;

import org.junit.Before;
import org.junit.Test;


public class GameBoardTest extends TestCase {

    private GameBoard mSubject;

    @Before
    public void setUp() throws Exception {
        mSubject = new GameBoard();
    }

    @Test
    public void testGetWinnerInCol() throws Exception {
        mSubject.setDebug(false);
        mSubject.play(GameBoard.Player.J1, 0, 0);
        mSubject.play(GameBoard.Player.J1, 0, 1);
        assertNull(mSubject.getWinner());
        mSubject.play(GameBoard.Player.J1, 0, 2);
        assertEquals(mSubject.getWinner(), GameBoard.Player.J1);
    }

    @Test
    public void testGetWinnerInRow() throws Exception {
        mSubject.play(GameBoard.Player.J1, 0, 0);
        mSubject.play(GameBoard.Player.J1, 1, 0);
        assertNull(mSubject.getWinner());
        mSubject.play(GameBoard.Player.J1, 2, 0);
        assertEquals(mSubject.getWinner(), GameBoard.Player.J1);
    }

    @Test
    public void testGetWinnerInDiagonalLeftToRight() throws Exception {
        mSubject.play(GameBoard.Player.J1, 0, 0);
        mSubject.play(GameBoard.Player.J1, 1, 1);
        assertNull(mSubject.getWinner());
        mSubject.play(GameBoard.Player.J1, 2, 2);
        assertEquals(mSubject.getWinner(), GameBoard.Player.J1);
    }

    @Test
    public void testGetWinnerInDiagonalRightToLeft() throws Exception {
        mSubject.play(GameBoard.Player.J1, 2, 2);
        mSubject.play(GameBoard.Player.J1, 1, 1);
        assertNull(mSubject.getWinner());
        mSubject.play(GameBoard.Player.J1, 0, 0);
        assertEquals(mSubject.getWinner(), GameBoard.Player.J1);
    }

    @Test
    public void testIsFill() throws Exception {
        assertFalse(mSubject.isFill(0, 0));
        mSubject.play(GameBoard.Player.J1, 0, 0);
        assertTrue(mSubject.isFill(0, 0));
    }

    @Test
    public void testUndo() throws Exception {
        assertFalse(mSubject.isFill(0, 1));
        mSubject.play(GameBoard.Player.J1, 0, 1);
        assertTrue(mSubject.isFill(0, 1));
        mSubject.undo();
        assertFalse(mSubject.isFill(0, 1));
    }

    @Test
    public void testGetPlayLeft() throws Exception {
        assertEquals(9, mSubject.getPlayLeft());
        mSubject.play(GameBoard.Player.J1, 2, 2);
        assertEquals(8, mSubject.getPlayLeft());
        mSubject.play(GameBoard.Player.J1, 1, 1);
        assertEquals(7, mSubject.getPlayLeft());
    }

    @Test
    public void testGetSize() throws Exception {
        assertEquals(3, mSubject.getSize());
    }
}