package com.skocken.tictactoeia.presentation.presenter;

import com.skocken.tictactoeia.GameBoard;
import com.skocken.tictactoeia.presentation.Board;

import junit.framework.TestCase;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

import java.util.List;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class BoardPresenterTest extends TestCase {

    private Board.IDataProvider mDataProvider;

    private Board.IView mBoardView;

    @Before
    public void setUp() throws Exception {
        mDataProvider = Mockito.mock(Board.IDataProvider.class);
        mBoardView = Mockito.mock(Board.IView.class);
    }

    @Test
    public void testBoardFillView() throws Exception {
        GameBoard.Player[][] initBoard =
                {
                        {GameBoard.Player.J1, GameBoard.Player.EMPTY, GameBoard.Player.J1},
                        {GameBoard.Player.J2, GameBoard.Player.J1, GameBoard.Player.J1},
                        {GameBoard.Player.EMPTY, GameBoard.Player.J2, GameBoard.Player.J2}

                };

        Board.IView.BoxValue[][] boxValuesExpected =
                {
                        {Board.IView.BoxValue.CROSS,
                                Board.IView.BoxValue.EMPTY,
                                Board.IView.BoxValue.CROSS},
                        {Board.IView.BoxValue.ROUND,
                                Board.IView.BoxValue.CROSS,
                                Board.IView.BoxValue.CROSS},
                        {Board.IView.BoxValue.EMPTY,
                                Board.IView.BoxValue.ROUND,
                                Board.IView.BoxValue.ROUND}
                };

        GameBoard gameBoard = new GameBoard();
        gameBoard.setBoard(initBoard);
        when(mDataProvider.getGameBoard()).thenReturn(gameBoard);

        BoardPresenter boardPresenter = new BoardPresenter(mDataProvider, mBoardView);

        ArgumentCaptor<Integer> xArguments = ArgumentCaptor.forClass(Integer.class);
        ArgumentCaptor<Integer> yArguments = ArgumentCaptor.forClass(Integer.class);
        ArgumentCaptor<Board.IView.BoxValue> boxValueArguments
                = ArgumentCaptor.forClass(Board.IView.BoxValue.class);

        verify(mBoardView, times(9)).setBoxValue(xArguments.capture(), yArguments.capture(),
                boxValueArguments.capture());

        List<Integer> capturedX = xArguments.getAllValues();
        List<Integer> capturedY = yArguments.getAllValues();
        List<Board.IView.BoxValue> capturedBoxValue = boxValueArguments.getAllValues();

        Board.IView.BoxValue[][] boxValuesCapture = new Board.IView.BoxValue[3][3];

        for (int i = 0; i < 9; i++) {
            boxValuesCapture[capturedY.get(i)][capturedX.get(i)] = capturedBoxValue.get(i);
        }

        Assert.assertArrayEquals(boxValuesExpected, boxValuesCapture);
    }
}